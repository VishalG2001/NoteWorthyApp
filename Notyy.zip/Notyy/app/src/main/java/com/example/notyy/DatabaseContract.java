//package com.example.notyy;
//
//import android.provider.BaseColumns;
//
//public final class DatabaseContract {
//
//    private DatabaseContract() {
//        // Private constructor to prevent instantiation
//    }
//
//    public static class NoteEntry implements BaseColumns {
//        public static final String TABLE_NAME = "notes";
//        public static final String COLUMN_TITLE = "title";
//        public static final String COLUMN_CONTENT = "content";
//    }
//}
